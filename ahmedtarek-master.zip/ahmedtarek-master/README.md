Interns First task

It is required to create a database with one table User ( ID, Name, Email, Password, Age ), this service should provide 6 API calls using gin library & postgresql database.
steps:<br>
1- create a new branch with your name. <br>
2- write your code.<br> 
3- make a postman collection to test it.<br>
<br>
The Required Apis <br>
1- Create User <br>
2- Update User <br>
3- Get User <br>
4- Get Users <br>
5- Delete User <br>
6- Login User (using email & password returning a message welcome [username] )

<br>
required to use ORM like GORM & gin library.

